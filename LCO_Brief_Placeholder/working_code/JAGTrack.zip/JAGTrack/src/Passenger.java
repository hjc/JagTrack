
public class Passenger {
	private String jagNumber;
	private String email;
	private String firstName;
	private String lastName;
}
