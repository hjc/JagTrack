
public class Stop {
	int stopNumber;
}
