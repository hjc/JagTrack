
public class Itenerary {
	
	Stop departure;
	Stop destination;

}
