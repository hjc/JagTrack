
public class Route {

	public enum Color{
		RED, BLUE, YELLOW, GREEN, WHITE
	}
	
	Color color;
	Coverage coverage;
	Stop[] stops;
	Bus[] bus;
	
}
