import java.sql.Time;
public class Coverage {

	private Time startTime;
	private Time endTime;
	
}
