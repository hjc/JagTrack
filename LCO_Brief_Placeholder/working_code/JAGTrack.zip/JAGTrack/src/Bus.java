import java.sql.Time;


public class Bus{
	private String id;
	private int numberOfSeats;
	private Time arrivalTime;
}
